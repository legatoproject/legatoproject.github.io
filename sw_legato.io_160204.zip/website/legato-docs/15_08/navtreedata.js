var NAVTREE =
[
  [ "LEGATO", "index.html", [
    [ "Reference", "index.html", "index" ],
    [ "File List", "files.html", "files" ]
  ] ]
];

var NAVTREEINDEX =
[
"about_docs.html",
"c_le_voicecall.html#c_le_voicecall_incoming",
"ccoding_stds_param.html",
"le__adc__interface_8h.html",
"le__avdata__interface_8h.html#a45fab2cd681a4e0c20b4e0a4fd97aa9a",
"le__ecall__interface_8h.html#a777e8d6608b5e40f73696904471519cfa37adae3ab192525db0848a626869f9bf",
"le__info__interface_8h.html#ae4a7baef2aac776edefefab68b74a7c6",
"le__mdc__interface_8h.html#ad1fe8909ae01a2f7e33fdbdc6938bf17afeaf658e0acdb7413caef8fee314cfbb",
"le__mrc__interface_8h.html#acb434a9f91afb5b6639baf3678ee9388",
"le__sms__interface_8h.html",
"le__sup__wdog__interface_8h_source.html",
"tools_target_cm.html#toolsTarget_cm_data"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';