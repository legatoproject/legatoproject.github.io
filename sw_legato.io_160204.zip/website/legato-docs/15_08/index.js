var index =
[
    [ "Get Started", "getstarted_main.html", "getstarted_main" ],
    [ "Basics", "basic_main.html", "basic_main" ],
    [ "Tools", "tools.html", "tools" ],
    [ "How To", "how_to_main.html", "how_to_main" ],
    [ "Definition Files", "def_files.html", "def_files" ],
    [ "Language-independent APIs", "language_independent_a_p_is.html", "language_independent_a_p_is" ],
    [ "Services APIs", "legato_services.html", "legato_services" ],
    [ "C Runtime Library", "c__a_p_is.html", "c__a_p_is" ],
    [ "Other Info", "other_info.html", "other_info" ],
    [ "About", "about_main.html", "about_main" ]
];